-- Bedaya Travel: run this entire file in Supabase SQL Editor.
-- IMPORTANT: never put a service_role key in the frontend.
create extension if not exists pgcrypto;

create table if not exists public.trips (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  destination text,
  trip_date date,
  price numeric(10,2) not null check (price >= 0),
  deposit numeric(10,2) not null check (deposit >= 0 and deposit <= price),
  capacity integer not null default 50 check (capacity > 0),
  pickup text not null,
  includes text not null default 'المواصلات والبرنامج',
  description text,
  image_url text,
  published boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.bookings (
  id uuid primary key default gen_random_uuid(),
  trip_id uuid not null references public.trips(id) on delete restrict,
  full_name text not null check (length(trim(full_name)) between 2 and 120),
  phone text not null check (length(trim(phone)) between 7 and 30),
  people integer not null check (people between 1 and 10),
  deposit_due numeric(10,2) not null check (deposit_due >= 0),
  total_price numeric(10,2) not null check (total_price >= deposit_due),
  transaction_reference text not null check (length(trim(transaction_reference)) between 2 and 120),
  notes text,
  status text not null default 'pending_review'
    check (status in ('pending_review','confirmed','cancelled')),
  payment_status text not null default 'pending_review'
    check (payment_status in ('pending_review','paid','rejected')),
  created_at timestamptz not null default now()
);

create index if not exists trips_published_date_idx on public.trips (published, trip_date);
create index if not exists bookings_trip_status_idx on public.bookings (trip_id, status);
create index if not exists bookings_created_at_idx on public.bookings (created_at desc);

create table if not exists public.admin_users (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

alter table public.trips enable row level security;
alter table public.bookings enable row level security;
alter table public.admin_users enable row level security;

drop policy if exists "Admins can read own admin record" on public.admin_users;
create policy "Admins can read own admin record" on public.admin_users
  for select to authenticated using (user_id = auth.uid());

-- Public users can only read published trips. Admin privileges require an explicit allowlist entry.
drop policy if exists "Public read published trips" on public.trips;
create policy "Public read published trips" on public.trips
  for select to anon, authenticated using (
    published = true
    or exists (select 1 from public.admin_users au where au.user_id = auth.uid())
  );

drop policy if exists "Authenticated admins manage trips" on public.trips;
create policy "Authenticated admins manage trips" on public.trips
  for all to authenticated
  using (exists (select 1 from public.admin_users au where au.user_id = auth.uid()))
  with check (exists (select 1 from public.admin_users au where au.user_id = auth.uid()));

-- Customers can submit booking requests. Public clients cannot read bookings.
drop policy if exists "Public submit booking requests" on public.bookings;
create policy "Public submit booking requests" on public.bookings
  for insert to anon, authenticated with check (
    status = 'pending_review'
    and payment_status = 'pending_review'
    and people between 1 and 10
    and exists (
      select 1 from public.trips t
      where t.id = trip_id
        and t.published = true
        and t.trip_date >= current_date
        and deposit_due = t.deposit * people
        and total_price = t.price * people
    )
  );

drop policy if exists "Authenticated admins read bookings" on public.bookings;
create policy "Authenticated admins read bookings" on public.bookings
  for select to authenticated
  using (exists (select 1 from public.admin_users au where au.user_id = auth.uid()));

drop policy if exists "Authenticated admins update bookings" on public.bookings;
create policy "Authenticated admins update bookings" on public.bookings
  for update to authenticated
  using (exists (select 1 from public.admin_users au where au.user_id = auth.uid()))
  with check (exists (select 1 from public.admin_users au where au.user_id = auth.uid()));

-- Seed the first trip. If you run this script more than once, it won't duplicate the seed row.
insert into public.trips
  (title, destination, trip_date, price, deposit, capacity, pickup, includes, description, image_url, published)
select
  'رحلة الفيوم — وادي الريان والبحيرة السحرية',
  'الفيوم، مصر',
  date '2026-11-06',
  500,
  250,
  50,
  'كفر الدوار – مساكن البيضا – شارع المدرسة الثانوية',
  'المواصلات والبرنامج',
  'يوم لاكتشاف طبيعة الفيوم وزيارة وادي الريان والبحيرة السحرية. يرجى تأكيد التوقيت والبرنامج النهائي مع الإدارة.',
  'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1400&q=85',
  true
where not exists (
  select 1 from public.trips
  where title = 'رحلة الفيوم — وادي الريان والبحيرة السحرية'
    and trip_date = date '2026-11-06'
);

-- IMPORTANT: after creating your manager account in Authentication -> Users,
-- add ONLY that account's UUID to the allowlist using the SQL below (replace UUID):
-- insert into public.admin_users (user_id) values ('YOUR-AUTH-USER-UUID');
-- Never expose the Supabase service_role key in frontend code.
