import React, { useEffect, useMemo, useState } from 'react';
import {
  ArrowLeft, CalendarDays, MapPin, Users, Wallet, ShieldCheck, Menu,
  X, Plus, LogIn, LogOut, ClipboardList, Plane, Clock, CheckCircle2,
  AlertCircle, Phone, Copy, ExternalLink, Trash2, Eye, EyeOff, RefreshCw
} from 'lucide-react';
import { hasSupabaseConfig, supabase, walletNumber, walletProvider, supportPhone } from './lib/supabase.js';

const SEED_TRIP = {
  id: 'seed-fayoum',
  title: 'رحلة الفيوم — وادي الريان والبحيرة السحرية',
  destination: 'الفيوم، مصر',
  trip_date: '2026-11-06',
  price: 500,
  deposit: 250,
  capacity: 50,
  booked_count: 0,
  pickup: 'كفر الدوار – مساكن البيضا – شارع المدرسة الثانوية',
  includes: 'المواصلات والبرنامج',
  description: 'يوم لاكتشاف طبيعة الفيوم وزيارة وادي الريان والبحيرة السحرية. يُرجى التأكد من تفاصيل التوقيت والبرنامج النهائي مع الإدارة قبل تأكيد الحجز.',
  image_url: 'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1400&q=85',
  published: true
};

const money = (n) => `${Number(n || 0).toLocaleString('ar-EG')} جنيه`;
const dateLabel = (value) => {
  if (!value) return 'الموعد يحدد لاحقًا';
  return new Date(`${value}T12:00:00`).toLocaleDateString('ar-EG', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
};
const blankTrip = () => ({
  title: '', destination: '', trip_date: '', price: '500', deposit: '250',
  capacity: '50', pickup: '', includes: 'المواصلات والبرنامج', description: '',
  image_url: '', published: true
});

export default function App() {
  const [page, setPage] = useState('home');
  const [trips, setTrips] = useState([]);
  const [loadingTrips, setLoadingTrips] = useState(true);
  const [selectedTrip, setSelectedTrip] = useState(null);
  const [bookingTrip, setBookingTrip] = useState(null);
  const [notice, setNotice] = useState('');
  const [mobileMenu, setMobileMenu] = useState(false);
  const [session, setSession] = useState(null);
  const [adminEmail, setAdminEmail] = useState('');
  const [adminPassword, setAdminPassword] = useState('');
  const [adminBusy, setAdminBusy] = useState(false);
  const [bookings, setBookings] = useState([]);
  const [tripForm, setTripForm] = useState(blankTrip());
  const [editingId, setEditingId] = useState(null);
  const [adminTab, setAdminTab] = useState('bookings');
  const [bookingForm, setBookingForm] = useState({ full_name: '', phone: '', people: '1', transaction_reference: '', notes: '' });
  const [submittingBooking, setSubmittingBooking] = useState(false);
  const [showHidden, setShowHidden] = useState(false);

  useEffect(() => {
    loadTrips();
    if (!supabase) return;
    supabase.auth.getSession().then(({ data }) => setSession(data.session));
    const { data: listener } = supabase.auth.onAuthStateChange((_event, nextSession) => {
      setSession(nextSession);
      if (!nextSession) setBookings([]);
    });
    return () => listener.subscription.unsubscribe();
  }, []);

  async function loadTrips() {
    setLoadingTrips(true);
    if (!hasSupabaseConfig) {
      setTrips([SEED_TRIP]);
      setLoadingTrips(false);
      return;
    }
    const { data, error } = await supabase.from('trips').select('*').order('trip_date', { ascending: true });
    if (error) {
      setNotice(`تعذر تحميل الرحلات: ${error.message}`);
      setTrips([]);
    } else {
      setTrips(data || []);
    }
    setLoadingTrips(false);
  }

  async function loadBookings() {
    if (!supabase || !session) return;
    const { data, error } = await supabase.from('bookings')
      .select('*, trips(title, trip_date, price, deposit)')
      .order('created_at', { ascending: false });
    if (error) setNotice(`تعذر تحميل الحجوزات: ${error.message}`);
    else setBookings(data || []);
  }

  useEffect(() => {
    if (session) loadBookings();
  }, [session]);

  const visibleTrips = useMemo(() => trips.filter(t => showHidden || t.published), [trips, showHidden]);

  function openBooking(trip) {
    setBookingTrip(trip);
    setBookingForm({ full_name: '', phone: '', people: '1', transaction_reference: '', notes: '' });
    setNotice('');
  }

  async function submitBooking(e) {
    e.preventDefault();
    if (!bookingTrip) return;
    if (!hasSupabaseConfig || bookingTrip.id === 'seed-fayoum') {
      setNotice('الموقع حاليًا في وضع المعاينة. اربط Supabase وانشر قاعدة البيانات قبل استقبال حجوزات حقيقية.');
      return;
    }
    const people = Math.max(1, Math.floor(Number(bookingForm.people) || 1));
    if (!bookingForm.full_name.trim() || !bookingForm.phone.trim()) {
      setNotice('من فضلك اكتب الاسم ورقم الموبايل.');
      return;
    }
    if (!bookingForm.transaction_reference.trim()) {
      setNotice('اكتب رقم مرجع التحويل أو آخر أرقام العملية بعد التحويل. لا ترسل رقمك السري أو رمز OTP.');
      return;
    }
    setSubmittingBooking(true);
    const payload = {
      trip_id: bookingTrip.id,
      full_name: bookingForm.full_name.trim(),
      phone: bookingForm.phone.trim(),
      people,
      deposit_due: Number(bookingTrip.deposit) * people,
      total_price: Number(bookingTrip.price) * people,
      transaction_reference: bookingForm.transaction_reference.trim(),
      notes: bookingForm.notes.trim() || null,
      status: 'pending_review',
      payment_status: 'pending_review'
    };
    const { error } = await supabase.from('bookings').insert(payload);
    setSubmittingBooking(false);
    if (error) {
      setNotice(error.message.includes('capacity') ? 'عذرًا، لا توجد أماكن كافية لهذا العدد.' : `لم يتم تسجيل الحجز: ${error.message}`);
      return;
    }
    setBookingTrip(null);
    setNotice('تم استلام طلبك بنجاح. الحجز غير مؤكد حتى تراجع الإدارة التحويل وتؤكد الدفع. احتفظ بمرجع العملية.');
  }

  async function loginAdmin(e) {
    e.preventDefault();
    if (!supabase) { setNotice('أضف إعدادات Supabase في ملف .env أولًا.'); return; }
    setAdminBusy(true);
    const { error } = await supabase.auth.signInWithPassword({ email: adminEmail, password: adminPassword });
    setAdminBusy(false);
    if (error) setNotice('تعذر تسجيل الدخول. راجع البريد وكلمة المرور، وتأكد من إنشاء حساب المدير في Supabase.');
    else { setAdminPassword(''); setNotice('تم تسجيل الدخول.'); }
  }

  async function saveTrip(e) {
    e.preventDefault();
    if (!supabase || !session) return;
    const payload = {
      title: tripForm.title.trim(), destination: tripForm.destination.trim(),
      trip_date: tripForm.trip_date || null, price: Number(tripForm.price),
      deposit: Number(tripForm.deposit), capacity: Number(tripForm.capacity),
      pickup: tripForm.pickup.trim(), includes: tripForm.includes.trim(),
      description: tripForm.description.trim(), image_url: tripForm.image_url.trim() || null,
      published: Boolean(tripForm.published)
    };
    if (!payload.title || !payload.pickup || payload.price < 0 || payload.deposit < 0 || payload.deposit > payload.price || payload.capacity < 1) {
      setNotice('راجع بيانات الرحلة: السعر والسعة ومبلغ العربون ومكان التجمع.');
      return;
    }
    const query = editingId
      ? supabase.from('trips').update(payload).eq('id', editingId)
      : supabase.from('trips').insert(payload);
    const { error } = await query;
    if (error) setNotice(`تعذر حفظ الرحلة: ${error.message}`);
    else {
      setNotice('تم حفظ الرحلة.');
      setTripForm(blankTrip()); setEditingId(null); await loadTrips(); setAdminTab('trips');
    }
  }

  function editTrip(trip) {
    setEditingId(trip.id);
    setTripForm({
      title: trip.title || '', destination: trip.destination || '', trip_date: trip.trip_date || '',
      price: String(trip.price ?? 500), deposit: String(trip.deposit ?? 250),
      capacity: String(trip.capacity ?? 50), pickup: trip.pickup || '',
      includes: trip.includes || '', description: trip.description || '',
      image_url: trip.image_url || '', published: Boolean(trip.published)
    });
    setAdminTab('editor');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  async function deleteTrip(trip) {
    if (!supabase || !session) return;
    if (!window.confirm('هل تريد حذف الرحلة؟ إذا كان لها حجوزات مرتبطة، قد تمنع قاعدة البيانات الحذف للحفاظ على السجلات.')) return;
    const { error } = await supabase.from('trips').delete().eq('id', trip.id);
    if (error) setNotice(`لم يتم حذف الرحلة: ${error.message}`);
    else { setNotice('تم حذف الرحلة.'); await loadTrips(); }
  }

  async function updateBooking(id, changes) {
    if (!supabase || !session) return;
    const { error } = await supabase.from('bookings').update(changes).eq('id', id);
    if (error) setNotice(`تعذر تحديث الحجز: ${error.message}`);
    else { setNotice('تم تحديث الحجز.'); await loadBookings(); await loadTrips(); }
  }

  async function logout() {
    if (supabase) await supabase.auth.signOut();
    setPage('home');
  }

  const totalDue = bookingTrip ? Number(bookingTrip.deposit) * Math.max(1, Number(bookingForm.people) || 1) : 0;
  const tripBookedCount = (trip) => bookings.filter(b => b.trip_id === trip.id && b.status === 'confirmed').reduce((sum, b) => sum + Number(b.people), 0);

  return (
    <div className="app-shell">
      <header className="site-header">
        <div className="header-inner">
          <button className="brand" onClick={() => { setPage('home'); setMobileMenu(false); }} aria-label="الرئيسية">
            <span className="brand-mark"><Plane size={23}/></span>
            <span><strong>بداية ترافيل</strong><small>BEDAYA TRAVEL</small></span>
          </button>
          <button className="mobile-toggle" onClick={() => setMobileMenu(!mobileMenu)} aria-label="فتح القائمة">{mobileMenu ? <X/> : <Menu/>}</button>
          <nav className={mobileMenu ? 'nav open' : 'nav'}>
            <button onClick={() => { setPage('home'); setMobileMenu(false); }}>الرئيسية</button>
            <a href="#trips" onClick={() => setMobileMenu(false)}>الرحلات</a>
            <a href={`https://wa.me/2${supportPhone.replace(/\D/g, '').replace(/^2/, '')}`} target="_blank" rel="noreferrer">تواصل معنا</a>
            <button className="admin-nav" onClick={() => { setPage('admin'); setMobileMenu(false); }}>لوحة الإدارة <ShieldCheck size={16}/></button>
          </nav>
        </div>
      </header>

      <main>
        {page === 'home' && <>
          <section className="hero">
            <div className="hero-image" />
            <div className="hero-overlay" />
            <div className="hero-content container">
              <span className="eyebrow"><span className="eyebrow-dot"/> رحلتك تبدأ من هنا</span>
              <h1>اكتشف أماكن<br/><em>تستاهل تعيشها</em></h1>
              <p>اختار رحلتك الجاية، احجز مكانك بسهولة، واستعد لذكريات جديدة مع بداية ترافيل.</p>
              <a className="primary-button" href="#trips">اكتشف الرحلات <ArrowLeft size={18}/></a>
              <div className="hero-trust"><span><ShieldCheck size={17}/> حجز واضح</span><span><Wallet size={17}/> عربون معلوم</span><span><Users size={17}/> تنظيم جماعي</span></div>
            </div>
            <div className="hero-side-label">BEDAYA · TRAVEL · EXPLORE</div>
          </section>

          <section className="quick-facts container">
            <div><span className="fact-icon"><CalendarDays/></span><span><b>مواعيد واضحة</b><small>تفاصيل كل رحلة</small></span></div>
            <div><span className="fact-icon"><Wallet/></span><span><b>عربون مسبق</b><small>تأكيد يدوي للدفع</small></span></div>
            <div><span className="fact-icon"><Phone/></span><span><b>مساعدة مباشرة</b><small>{supportPhone}</small></span></div>
          </section>

          <section className="trips-section container" id="trips">
            <div className="section-heading"><div><span className="eyebrow dark">اختار وجهتك</span><h2>الرحلات القادمة</h2><p>أماكن جديدة، صحبة حلوة، وتجارب تفضل في الذاكرة.</p></div><span className="trip-count">{visibleTrips.length} رحلة</span></div>
            {!hasSupabaseConfig && <div className="setup-alert"><AlertCircle size={19}/><span>وضع معاينة: الرحلة المعروضة نموذج أولي. الحجز الفعلي يتطلب إعداد Supabase ونشر الموقع.</span></div>}
            {loadingTrips ? <div className="loading"><RefreshCw className="spin"/> جاري تحميل الرحلات...</div> :
              visibleTrips.length ? <div className="trip-grid">{visibleTrips.map(trip => {
                const remaining = Math.max(0, Number(trip.capacity || 0) - (Number(trip.booked_count || 0)));
                return <article className="trip-card" key={trip.id}>
                  <div className="trip-image-wrap"><img src={trip.image_url || SEED_TRIP.image_url} alt={trip.title} onError={(e) => { e.currentTarget.src = SEED_TRIP.image_url; }}/><span className="image-badge">رحلة مميزة</span><span className="trip-price">{money(trip.price)} <small>/ للفرد</small></span></div>
                  <div className="trip-body">
                    <div className="trip-destination"><MapPin size={15}/>{trip.destination || 'مصر'}</div>
                    <h3>{trip.title}</h3>
                    <p className="trip-desc">{trip.description || 'اكتشف وجهة جديدة مع بداية ترافيل.'}</p>
                    <div className="trip-meta"><span><CalendarDays size={16}/>{dateLabel(trip.trip_date)}</span><span><Users size={16}/>{remaining} مكان متاح (حسب التحديث)</span></div>
                    <div className="trip-bottom"><span className="deposit-label"><Wallet size={16}/> عربون {money(trip.deposit)}</span><button className="primary-button compact" onClick={() => { setSelectedTrip(trip); openBooking(trip); }}>احجز الآن <ArrowLeft size={16}/></button></div>
                    <button className="text-link" onClick={() => { setSelectedTrip(trip); setPage('trip'); }}>تفاصيل الرحلة</button>
                  </div>
                </article>;
              })}</div> : <div className="empty-state"><Plane size={34}/><h3>مفيش رحلات منشورة حاليًا</h3><p>تابعنا عشان تعرف أول ما تنزل رحلة جديدة.</p></div>}
          </section>

          <section className="cta-band"><div className="container cta-inner"><div><span className="eyebrow">مع بداية ترافيل</span><h2>الرحلة الحلوة بتبدأ بخطوة</h2><p>اختار رحلتك وخلي الباقي علينا.</p></div><a className="light-button" href="#trips">شوف الرحلات <ArrowLeft size={18}/></a></div></section>
        </>}

        {page === 'trip' && selectedTrip && <section className="container detail-page">
          <button className="back-button" onClick={() => setPage('home')}>← الرجوع للرحلات</button>
          <div className="detail-layout"><img className="detail-image" src={selectedTrip.image_url || SEED_TRIP.image_url} alt={selectedTrip.title}/><div className="detail-content"><span className="eyebrow dark">{selectedTrip.destination}</span><h1>{selectedTrip.title}</h1><div className="detail-meta"><span><CalendarDays/>{dateLabel(selectedTrip.trip_date)}</span><span><MapPin/>{selectedTrip.pickup}</span></div><p>{selectedTrip.description}</p><p><b>يشمل السعر:</b> {selectedTrip.includes}</p><div className="price-panel"><div><small>سعر الفرد</small><strong>{money(selectedTrip.price)}</strong></div><div><small>العربون للفرد</small><strong>{money(selectedTrip.deposit)}</strong></div></div><button className="primary-button" onClick={() => openBooking(selectedTrip)}>احجز مكانك الآن <ArrowLeft/></button></div></div>
        </section>}

        {page === 'admin' && <section className="container admin-page">
          <div className="admin-title"><div><span className="eyebrow dark">إدارة المنصة</span><h1>لوحة تحكم بداية ترافيل</h1><p>إدارة الرحلات والحجوزات من مكان واحد.</p></div>{session && <button className="outline-button" onClick={logout}><LogOut size={17}/> تسجيل الخروج</button>}</div>
          {!hasSupabaseConfig && <div className="setup-alert large"><AlertCircle/><div><b>الموقع غير مربوط بقاعدة البيانات حتى الآن</b><p>أكمل خطوات الإعداد في README، ثم أضف متغيرات Supabase إلى إعدادات النشر. لا يوجد تسجيل دخول إداري أو حفظ دائم قبل هذه الخطوة.</p></div></div>}
          {!session ? <form className="login-card" onSubmit={loginAdmin}><div className="login-icon"><ShieldCheck size={30}/></div><h2>دخول المدير</h2><p>استخدم حساب المدير الذي أنشأته في لوحة Supabase. لا يوجد حساب افتراضي داخل الموقع.</p><label>البريد الإلكتروني<input type="email" value={adminEmail} onChange={e => setAdminEmail(e.target.value)} placeholder="admin@example.com" required/></label><label>كلمة المرور<input type="password" value={adminPassword} onChange={e => setAdminPassword(e.target.value)} placeholder="كلمة المرور" required/></label><button className="primary-button full" disabled={adminBusy}>{adminBusy ? 'جاري الدخول...' : <><LogIn size={18}/> تسجيل الدخول</>}</button></form> :
            <>
              <div className="admin-tabs"><button className={adminTab === 'bookings' ? 'active' : ''} onClick={() => setAdminTab('bookings')}><ClipboardList size={17}/> الحجوزات ({bookings.length})</button><button className={adminTab === 'trips' ? 'active' : ''} onClick={() => setAdminTab('trips')}><Plane size={17}/> الرحلات</button><button className={adminTab === 'editor' ? 'active' : ''} onClick={() => { setAdminTab('editor'); if (!editingId) setTripForm(blankTrip()); }}><Plus size={17}/> {editingId ? 'تعديل الرحلة' : 'إضافة رحلة'}</button></div>
              {adminTab === 'bookings' && <div className="admin-table-wrap"><div className="table-toolbar"><h2>طلبات الحجز</h2><button className="outline-button" onClick={loadBookings}><RefreshCw size={16}/> تحديث</button></div>{bookings.length === 0 ? <div className="empty-state small"><ClipboardList/><p>لا توجد حجوزات حتى الآن.</p></div> : <div className="booking-list">{bookings.map(b => <article className="booking-row" key={b.id}><div className="booking-main"><b>{b.full_name}</b><span>{b.trips?.title || 'رحلة'}</span><small>{b.phone} · {b.people} فرد · العربون {money(b.deposit_due)}</small><small>مرجع التحويل: {b.transaction_reference || 'غير مسجل'}</small><small>تاريخ الطلب: {new Date(b.created_at).toLocaleString('ar-EG')}</small></div><div className="booking-actions"><span className={`status status-${b.status}`}>{statusLabel(b.status)}</span><span className={`status payment-${b.payment_status}`}>{paymentLabel(b.payment_status)}</span>{b.payment_status !== 'paid' && <button className="mini-success" onClick={() => updateBooking(b.id, { payment_status: 'paid', status: 'confirmed' })}><CheckCircle2 size={15}/> تأكيد الدفع والحجز</button>}{b.status !== 'cancelled' && <button className="mini-danger" onClick={() => updateBooking(b.id, { status: 'cancelled' })}>إلغاء</button>}</div></article>)}</div>}</div>}
              {adminTab === 'trips' && <div className="admin-table-wrap"><div className="table-toolbar"><h2>الرحلات</h2><button className="primary-button compact" onClick={() => { setEditingId(null); setTripForm(blankTrip()); setAdminTab('editor'); }}><Plus size={16}/> رحلة جديدة</button></div><div className="admin-trip-list">{trips.map(t => <article key={t.id} className="admin-trip-row"><img src={t.image_url || SEED_TRIP.image_url} alt=""/><div><b>{t.title}</b><small>{dateLabel(t.trip_date)} · {money(t.price)} للفرد · سعة {t.capacity}</small><span className={t.published ? 'published' : 'unpublished'}>{t.published ? 'منشورة' : 'مسودة'}</span></div><div className="row-actions"><button className="icon-button" title="تعديل" onClick={() => editTrip(t)}><Eye size={17}/></button><button className="icon-button danger" title="حذف" onClick={() => deleteTrip(t)}><Trash2 size={17}/></button></div></article>)}</div></div>}
              {adminTab === 'editor' && <form className="trip-editor" onSubmit={saveTrip}><div className="table-toolbar"><h2>{editingId ? 'تعديل الرحلة' : 'إضافة رحلة جديدة'}</h2>{editingId && <button type="button" className="outline-button" onClick={() => { setEditingId(null); setTripForm(blankTrip()); }}>إلغاء التعديل</button>}</div><div className="form-grid"><label className="wide">اسم الرحلة<input value={tripForm.title} onChange={e => setTripForm({...tripForm,title:e.target.value})} required placeholder="مثال: رحلة الفيوم"/></label><label>الوجهة<input value={tripForm.destination} onChange={e => setTripForm({...tripForm,destination:e.target.value})} placeholder="الفيوم، مصر"/></label><label>تاريخ الرحلة<input type="date" value={tripForm.trip_date} onChange={e => setTripForm({...tripForm,trip_date:e.target.value})}/></label><label>السعر للفرد (جنيه)<input type="number" min="0" value={tripForm.price} onChange={e => setTripForm({...tripForm,price:e.target.value})} required/></label><label>العربون للفرد (جنيه)<input type="number" min="0" value={tripForm.deposit} onChange={e => setTripForm({...tripForm,deposit:e.target.value})} required/></label><label>السعة الإجمالية<input type="number" min="1" value={tripForm.capacity} onChange={e => setTripForm({...tripForm,capacity:e.target.value})} required/></label><label className="wide">مكان التجمع<input value={tripForm.pickup} onChange={e => setTripForm({...tripForm,pickup:e.target.value})} required/></label><label className="wide">السعر يشمل<input value={tripForm.includes} onChange={e => setTripForm({...tripForm,includes:e.target.value})}/></label><label className="wide">رابط صورة الرحلة<input type="url" value={tripForm.image_url} onChange={e => setTripForm({...tripForm,image_url:e.target.value})} placeholder="https://..."/></label><label className="wide">وصف الرحلة<textarea rows="4" value={tripForm.description} onChange={e => setTripForm({...tripForm,description:e.target.value})}/></label><label className="check-label"><input type="checkbox" checked={tripForm.published} onChange={e => setTripForm({...tripForm,published:e.target.checked})}/> نشر الرحلة للعملاء</label></div><button className="primary-button full"><CheckCircle2 size={18}/> حفظ الرحلة</button></form>}
            </>}
        </section>}
      </main>

      <footer className="site-footer"><div className="container footer-inner"><div className="brand footer-brand"><span className="brand-mark"><Plane size={21}/></span><span><strong>بداية ترافيل</strong><small>BEDAYA TRAVEL</small></span></div><p>رحلتك تبدأ من هنا.</p><a href={`https://wa.me/2${supportPhone.replace(/\D/g, '').replace(/^2/, '')}`} target="_blank" rel="noreferrer"><Phone size={16}/> {supportPhone}</a><small>© {new Date().getFullYear()} بداية ترافيل — جميع الحقوق محفوظة</small></div></footer>

      {notice && <div className="toast" role="status"><span>{notice}</span><button onClick={() => setNotice('')} aria-label="إغلاق"><X size={17}/></button></div>}

      {bookingTrip && <div className="modal-backdrop" onClick={() => setBookingTrip(null)}><div className="booking-modal" onClick={e => e.stopPropagation()}><button className="modal-close" onClick={() => setBookingTrip(null)} aria-label="إغلاق"><X/></button><span className="eyebrow dark">احجز رحلتك</span><h2>{bookingTrip.title}</h2><p className="modal-subtitle">املأ بياناتك ثم حوّل العربون للمحفظة الموضحة. الحجز يظل قيد المراجعة حتى تأكيد الإدارة.</p><form onSubmit={submitBooking}><label>الاسم بالكامل<input value={bookingForm.full_name} onChange={e => setBookingForm({...bookingForm,full_name:e.target.value})} required autoComplete="name" placeholder="اسمك بالكامل"/></label><label>رقم الموبايل<input type="tel" value={bookingForm.phone} onChange={e => setBookingForm({...bookingForm,phone:e.target.value})} required autoComplete="tel" placeholder="01xxxxxxxxx"/></label><label>عدد الأفراد<select value={bookingForm.people} onChange={e => setBookingForm({...bookingForm,people:e.target.value})}>{Array.from({length:Math.min(10,Number(bookingTrip.capacity)||10)},(_,i)=><option key={i} value={i+1}>{i+1} {i===0?'فرد':'أفراد'}</option>)}</select></label><div className="payment-box"><div className="payment-box-title"><Wallet size={19}/><b>تفاصيل العربون</b></div><div className="payment-line"><span>عربون الفرد</span><b>{money(bookingTrip.deposit)}</b></div><div className="payment-line total"><span>إجمالي العربون</span><strong>{money(totalDue)}</strong></div><div className="wallet-detail"><small>{walletProvider}</small><strong dir="ltr">{walletNumber}</strong><button type="button" className="copy-button" onClick={() => { navigator.clipboard?.writeText(walletNumber); setNotice('تم نسخ رقم المحفظة إذا كان المتصفح يسمح بالنسخ.'); }}><Copy size={14}/> نسخ الرقم</button></div><p className="safety-note">حوّل العربون إلى رقم المحفظة أعلاه، ثم اكتب رقم مرجع العملية. لا تدخل الرقم السري للمحفظة أو رمز OTP في الموقع.</p></div><label>رقم مرجع التحويل / رقم العملية<input value={bookingForm.transaction_reference} onChange={e => setBookingForm({...bookingForm,transaction_reference:e.target.value})} required placeholder="رقم العملية من رسالة التحويل"/></label><label>ملاحظات (اختياري)<textarea rows="2" value={bookingForm.notes} onChange={e => setBookingForm({...bookingForm,notes:e.target.value})} placeholder="أي تفاصيل إضافية"/></label><button className="primary-button full" disabled={submittingBooking}>{submittingBooking ? 'جاري إرسال الطلب...' : <>إرسال طلب الحجز <ArrowLeft size={18}/></>}</button><p className="fine-print">إرسال الطلب لا يعني تأكيد الحجز. سيتم التواصل معك بعد مراجعة التحويل وتوفر الأماكن.</p></form></div></div>}
    </div>
  );
}

function statusLabel(status) {
  return ({pending_review:'بانتظار المراجعة',confirmed:'مؤكد',cancelled:'ملغي'})[status] || status || '—';
}
function paymentLabel(status) {
  return ({pending_review:'الدفع قيد المراجعة',paid:'تم تأكيد الدفع',rejected:'التحويل غير معتمد'})[status] || status || '—';
}